/**
 * 
 */
/**
 * 
 */
module CSSE220FinalProject {
	requires java.desktop;
}