package snakegame.model;

public enum GameState {
    WAITING,
    RUNNING,
    GAME_OVER
}
